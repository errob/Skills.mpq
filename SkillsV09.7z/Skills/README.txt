Install

Files included:
skills.txt 
skillsdesc.txt
pettype.txt
missiles.txt
monstats.txt

Copy them into your D2R Folder
C:\Battle.net\Diablo II Resurrected\mods\Skills\Skills.mpq\data\global\excel
Make sure you got the "modinfo.json" in
D:\Battle.net\Diablo II Resurrected\mods\Skills\Skills.mpq

Create a Shortcut for your Game and add "-mod Skills -txt" to Target
"C:\Battle.net\Diablo II Resurrected\D2R.exe" -mod Skills -txt

You can use the Files for other Singleplayer Mods too.
Although some SP Mods made overlapping changes to some secondary .txt
If you want to merge them, my changes for easier copy paste

Changed Rows in pettype.txt
5,13-17,22-28
Changed Rows in missiles.txt
210-213
Changed Rows in monstats.txt
291-294, 365-366, 423-431

V0.9
Necro Update

Summoning Necros
All Creatures have there stats buffed
All Golems at the same time useable
More Skeletons
More Skeleton Mages
Thread Management changed Golems > Skelet Warriors > Mages 
Skeleton Mages Damage increased *by a lot srsly 
Skeleton Mastery provides more Bonus
Golem Mastery provides more Bonus
Summon Resist provides more Bonus

Bone Necros
Synergy provide bigger Bonus to free up Skillpoints and incresed Damage overall
Teeth Mana reduced
Teeth Damage and Damage Scaling changed (viable for leveling)
Bone Armor provides Synergies instead of Bone Wall
Bone Spirit provides Synergies for Bone Armor


